namespace Inheritance.MapObjects
{
    public class Army
    {
        public int Power { get; set; }
    }
}
