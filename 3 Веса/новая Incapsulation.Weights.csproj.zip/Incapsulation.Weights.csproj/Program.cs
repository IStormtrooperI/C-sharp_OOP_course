using NUnitLite;
using System;

class Program
{
	static void Main(string[] args)
	{
		new AutoRun().Execute(args);
		Console.ReadLine();
	}
}
